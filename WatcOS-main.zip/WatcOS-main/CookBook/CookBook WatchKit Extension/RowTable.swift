//
//  RowTable.swift
//  CookBook
//
//  Created by Student on 04.03.2022.
//

import WatchKit

class RowTable: NSObject {
    
    @IBOutlet weak var rowPicture: WKInterfaceImage!
    @IBOutlet weak var rowRecipeName: WKInterfaceLabel!

}
